package ljwao94.utill;

public class Cw {
	public static void w(String s) {
		System.out.print(s);
	}
	public static void wn(String s) {
		System.out.println(s);
	}
	// wn 함수 - 오버로딩
	// 그냥 엔터하나 넣어주는 함수.
	public static void wn() {
		System.out.println();
	}
}
