package ljwao94;

import ljwao94.utill.Cw;

public class ProcRedWine {

	public static void run() {
		for (Product p : KioskObj.products) { // 메뉴출력
			Cw.wn(p.name + " " + p.price + "원");
		}
		yy: while (true) {

			Cw.wn("[1.마츠 엘 피카로/2.19 크라임스, 스눕독/3.카사 로호, 마초맨/4.부츠레그 프리퀄/5.오린스위프트 팔레르모/6.산타리타 힐즈, 루지인/x.이전메뉴로]");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(0).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(0))); // 오더 추가
				break;
			case "2":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(1).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(1))); // 오더 추가
				break;
			case "3":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(2).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(2))); // 오더 추가
				break;
			case "4":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(3).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(3))); // 오더 추가
				break;
			case "5":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(4).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(4))); // 오더 추가
				break;
			case "6":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(5).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(5))); // 오더 추가
				break;
			case "x":
				Cw.wn("이전 메뉴 이동");
				break yy;
			}
		}
	}
}
