package ljwao94;

import java.util.ArrayList;
import java.util.Scanner;

public class KioskObj {
	public static ArrayList<Order> basket = new ArrayList<>();	//주문들
	public static ArrayList<Product> products = new ArrayList<>();	//상품들
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
	

	
	public static void productLoad() {
		products.add(new Product("마츠 엘 피카로",32000));	
		products.add(new Product("19 크라임스, 스눕독",34000));
		products.add(new Product("카사 로호, 마초맨",52000));
		products.add(new Product("부츠레그 프리퀄",79000));
		products.add(new Product("오린스위프트 팔레르모",98000));
		products.add(new Product("산타리타 힐즈, 루지인",179000));//여기까지 레드와인
		products.add(new Product("모지, 말보로 소비뇽블랑",18000));
		products.add(new Product("타파스, 베르데호",20000));
		products.add(new Product("푸나무, 소비뇽블랑",32000));	
		products.add(new Product("모젤란드, 아방가르데",38000));
		products.add(new Product("피코마카리오, 피에몬테 비오니에 에스테로사",40000));
		products.add(new Product("오린스위프트, 블랭크스테어 소비뇽블랑",90000));//여기까지 화이트와인
		products.add(new Product("클림트 키스 뀌베 브뤼",30000));
		products.add(new Product("판티니, 그랑뀌베 스왈로브스키",34000));
		products.add(new Product("도멘디아블, 로제봉봉",40000));	
		products.add(new Product("멈그랑꼬르동", 740000));
		products.add(new Product("모엣샹동, 아이스임페리얼",78000));
		products.add(new Product("모엣샹동, 로제임페리얼",82000));//여기까지 스파클링와인
		products.add(new Product("칸티나 마릴리나 페델리에 비안코",30000));
		products.add(new Product("칸티나 마릴리나 페델리에 로사또",32000));
		products.add(new Product("챠밍래빗, 샤르도네",32000));
		products.add(new Product("보데스가 알베로, 폴리존 화이트",38000));	
		products.add(new Product("보데스가 알베로, 폴리존 로제", 42000));
		products.add(new Product("로모 베르드 펫낫",88000));//여기까지 내추럴와인
	}
}
