package ljwao94;

import ljwao94.utill.Cw;

public class ProcSparklingWine {

	public static void run() {
		for (Product p : KioskObj.products) { // 메뉴출력
			Cw.wn(p.name + " " + p.price + "원");
		}
		yy: while (true) {

			Cw.wn("[1.클림트 키스 뀌베 브뤼/2.판티니, 그랑뀌베 스왈로브스키/3.도멘디아블, 로제봉봉/4.멈그랑꼬르동/5.모엣샹동, 아이스임페리얼/6.모엣샹동, 로제임페리얼/x.이전메뉴로]");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(12).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(12))); // 오더 추가
				break;
			case "2":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(13).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(13))); // 오더 추가
				break;
			case "3":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(14).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(14))); // 오더 추가
				break;
			case "4":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(15).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(15))); // 오더 추가
				break;
			case "5":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(16).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(16))); // 오더 추가
				break;
			case "6":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(17).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(17)));
				break;
			case "x":
				Cw.wn("이전 메뉴 이동");
				break yy;
			}
		}
	}
}
