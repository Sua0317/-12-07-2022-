package ljwao94;

public class Order {
	public Product selectedProduct;
	public int optionDeliveryToGo = 0;	//1: 택배 Delivery, 2: 선물포장 ToGo

	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}

	public Order(Product selectedProduct, int optionDeliveryToGo) {
		this.selectedProduct = selectedProduct;
		this.optionDeliveryToGo = optionDeliveryToGo;
	}
}
