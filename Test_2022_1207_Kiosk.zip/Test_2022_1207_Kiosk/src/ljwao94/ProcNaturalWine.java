package ljwao94;

import ljwao94.utill.Cw;

public class ProcNaturalWine {

	public static void run() {
		for (Product p : KioskObj.products) { // 메뉴출력
			Cw.wn(p.name + " " + p.price + "원");
		}
		yy: while (true) {

			Cw.wn("[1.칸티나 마릴리나 페델리에 비안코/2.칸티나 마릴리나 페델리에 로사또/3.챠밍래빗, 샤르도네/4.보데스가 알베로, 폴리존 화이트/5.보데스가 알베로, 폴리존 로제/6.로모 베르드 펫낫/x.이전메뉴로]");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(18).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(18))); // 오더 추가
				break;
			case "2":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(19).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(19))); // 오더 추가
				break;
			case "3":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(20).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(20))); // 오더 추가
				break;
			case "4":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(21).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(21))); // 오더 추가
				break;
			case "5":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(22).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(22))); // 오더 추가
				break;
			case "6":
				break;
			case "x":
				Cw.wn("이전 메뉴 이동");
				break yy;
			}
		}
	}
}
