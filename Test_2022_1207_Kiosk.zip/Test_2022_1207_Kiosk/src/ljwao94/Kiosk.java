package ljwao94;

import ljwao94.utill.Cw;

public class Kiosk {
	void run() {
		KioskObj.productLoad();	//상품불러오기(Product.java)
		Disp.title();
		xx:while(true) {
			Cw.wn("[1.레드와인/2.화이트와인/3.스파클링와인/4.내츄럴와인/e.프로그램종료]:");
			KioskObj.cmd = KioskObj.sc.next();
			switch(KioskObj.cmd) {
			case "1":
				ProcRedWine.run();
				break;
			case "2":
				ProcWhiteWine.run();
				break;
			case "3":
				ProcSparklingWine.run();
				break;
			case "4":
				ProcNaturalWine.run();
				break;
			case "e":
				Cw.wn("장바구니에 담긴 상품 갯수:"+KioskObj.basket.size());
				int sum = 0;
				for(Order o:KioskObj.basket) {	// for-each으로 적용
					sum = sum + o.selectedProduct.price;
				}
				Cw.wn("계산하실 금액은 :"+sum+"원 입니다.");
				
				Cw.wn("====================");	// 최종 합계 //
				for(Order o:KioskObj.basket) {
					Cw.wn(o.selectedProduct.name);
				}
				Cw.wn("====================");
				Cw.wn("프로그램종료");
				break xx;
			}
		}		
	}
}