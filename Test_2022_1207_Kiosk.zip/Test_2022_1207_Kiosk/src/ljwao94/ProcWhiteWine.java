package ljwao94;

import ljwao94.utill.Cw;

public class ProcWhiteWine {

	public static void run() {
		for (Product p : KioskObj.products) { // 메뉴출력
			Cw.wn(p.name + " " + p.price + "원");
		}
		yy: while (true) {

			Cw.wn("[1.모지, 말보로 소비뇽블랑/2.타파스, 베르데호/3.푸나무, 소비뇽블랑/4.모젤란드, 아방가르데/5.피코마카리오, 피에몬테 비오니에 에스테로사/6.오린스위프트, 블랭크스테어 소비뇽블랑/x.이전메뉴로]");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(6).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(6))); // 오더 추가
				break;
			case "2":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(7).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(7))); // 오더 추가
				break;
			case "3":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(8).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(8))); // 오더 추가
				break;
			case "4":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(9).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(9))); // 오더 추가
				break;
			case "5":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(10).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(10))); // 오더 추가
				break;
			case "6":
				ProcMenuOptionDeliveryToGo.run();
				Cw.wn(KioskObj.products.get(11).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(11))); // 오더 추가
				break;

			case "x":
				Cw.wn("이전 메뉴 이동");
				break yy;
			}
		}
	}
}
